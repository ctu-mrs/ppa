
"use strict";

let GetConfig = require('./GetConfig.js')
let SetConfig = require('./SetConfig.js')
let GetMetadata = require('./GetMetadata.js')

module.exports = {
  GetConfig: GetConfig,
  SetConfig: SetConfig,
  GetMetadata: GetMetadata,
};
