// Auto-generated. Do not edit!

// (in-package nimbro_log_transport.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let rosgraph_msgs = _finder('rosgraph_msgs');

//-----------------------------------------------------------

class LogMsg {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.msg = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('msg')) {
        this.msg = initObj.msg
      }
      else {
        this.msg = new rosgraph_msgs.msg.Log();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LogMsg
    // Serialize message field [id]
    bufferOffset = _serializer.uint32(obj.id, buffer, bufferOffset);
    // Serialize message field [msg]
    bufferOffset = rosgraph_msgs.msg.Log.serialize(obj.msg, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LogMsg
    let len;
    let data = new LogMsg(null);
    // Deserialize message field [id]
    data.id = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [msg]
    data.msg = rosgraph_msgs.msg.Log.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += rosgraph_msgs.msg.Log.getMessageSize(object.msg);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'nimbro_log_transport/LogMsg';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3bf1aa4ee5ce30014f8de11446314219';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint32 id
    rosgraph_msgs/Log msg
    ================================================================================
    MSG: rosgraph_msgs/Log
    ##
    ## Severity level constants
    ##
    byte DEBUG=1 #debug level
    byte INFO=2  #general level
    byte WARN=4  #warning level
    byte ERROR=8 #error level
    byte FATAL=16 #fatal/critical level
    ##
    ## Fields
    ##
    Header header
    byte level
    string name # name of the node
    string msg # message 
    string file # file the message came from
    string function # function the message came from
    uint32 line # line the message came from
    string[] topics # topic names that the node publishes
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LogMsg(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.msg !== undefined) {
      resolved.msg = rosgraph_msgs.msg.Log.Resolve(msg.msg)
    }
    else {
      resolved.msg = new rosgraph_msgs.msg.Log()
    }

    return resolved;
    }
};

module.exports = LogMsg;
