
"use strict";

let LogMsg = require('./LogMsg.js');
let LogBlock = require('./LogBlock.js');

module.exports = {
  LogMsg: LogMsg,
  LogBlock: LogBlock,
};
