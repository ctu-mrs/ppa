
"use strict";

let RTKBaseline = require('./RTKBaseline.js');
let NavControllerOutput = require('./NavControllerOutput.js');
let GlobalPositionTarget = require('./GlobalPositionTarget.js');
let LandingTarget = require('./LandingTarget.js');
let AttitudeTarget = require('./AttitudeTarget.js');
let LogEntry = require('./LogEntry.js');
let VehicleInfo = require('./VehicleInfo.js');
let OnboardComputerStatus = require('./OnboardComputerStatus.js');
let HilControls = require('./HilControls.js');
let RCIn = require('./RCIn.js');
let WaypointReached = require('./WaypointReached.js');
let Thrust = require('./Thrust.js');
let TerrainReport = require('./TerrainReport.js');
let CommandCode = require('./CommandCode.js');
let ManualControl = require('./ManualControl.js');
let Trajectory = require('./Trajectory.js');
let ESCStatusItem = require('./ESCStatusItem.js');
let CamIMUStamp = require('./CamIMUStamp.js');
let State = require('./State.js');
let PlayTuneV2 = require('./PlayTuneV2.js');
let ParamValue = require('./ParamValue.js');
let CompanionProcessStatus = require('./CompanionProcessStatus.js');
let RadioStatus = require('./RadioStatus.js');
let Param = require('./Param.js');
let BatteryStatus = require('./BatteryStatus.js');
let GPSRTK = require('./GPSRTK.js');
let WheelOdomStamped = require('./WheelOdomStamped.js');
let RCOut = require('./RCOut.js');
let ESCTelemetry = require('./ESCTelemetry.js');
let ADSBVehicle = require('./ADSBVehicle.js');
let HilGPS = require('./HilGPS.js');
let MagnetometerReporter = require('./MagnetometerReporter.js');
let ESCTelemetryItem = require('./ESCTelemetryItem.js');
let Waypoint = require('./Waypoint.js');
let GPSRAW = require('./GPSRAW.js');
let HilSensor = require('./HilSensor.js');
let TimesyncStatus = require('./TimesyncStatus.js');
let Tunnel = require('./Tunnel.js');
let MountControl = require('./MountControl.js');
let FileEntry = require('./FileEntry.js');
let LogData = require('./LogData.js');
let ESCInfoItem = require('./ESCInfoItem.js');
let ESCInfo = require('./ESCInfo.js');
let ActuatorControl = require('./ActuatorControl.js');
let Vibration = require('./Vibration.js');
let HilStateQuaternion = require('./HilStateQuaternion.js');
let Altitude = require('./Altitude.js');
let StatusText = require('./StatusText.js');
let HomePosition = require('./HomePosition.js');
let RTCM = require('./RTCM.js');
let ExtendedState = require('./ExtendedState.js');
let DebugValue = require('./DebugValue.js');
let CameraImageCaptured = require('./CameraImageCaptured.js');
let WaypointList = require('./WaypointList.js');
let GPSINPUT = require('./GPSINPUT.js');
let ESCStatus = require('./ESCStatus.js');
let EstimatorStatus = require('./EstimatorStatus.js');
let HilActuatorControls = require('./HilActuatorControls.js');
let OverrideRCIn = require('./OverrideRCIn.js');
let PositionTarget = require('./PositionTarget.js');
let OpticalFlowRad = require('./OpticalFlowRad.js');
let VFR_HUD = require('./VFR_HUD.js');
let Mavlink = require('./Mavlink.js');

module.exports = {
  RTKBaseline: RTKBaseline,
  NavControllerOutput: NavControllerOutput,
  GlobalPositionTarget: GlobalPositionTarget,
  LandingTarget: LandingTarget,
  AttitudeTarget: AttitudeTarget,
  LogEntry: LogEntry,
  VehicleInfo: VehicleInfo,
  OnboardComputerStatus: OnboardComputerStatus,
  HilControls: HilControls,
  RCIn: RCIn,
  WaypointReached: WaypointReached,
  Thrust: Thrust,
  TerrainReport: TerrainReport,
  CommandCode: CommandCode,
  ManualControl: ManualControl,
  Trajectory: Trajectory,
  ESCStatusItem: ESCStatusItem,
  CamIMUStamp: CamIMUStamp,
  State: State,
  PlayTuneV2: PlayTuneV2,
  ParamValue: ParamValue,
  CompanionProcessStatus: CompanionProcessStatus,
  RadioStatus: RadioStatus,
  Param: Param,
  BatteryStatus: BatteryStatus,
  GPSRTK: GPSRTK,
  WheelOdomStamped: WheelOdomStamped,
  RCOut: RCOut,
  ESCTelemetry: ESCTelemetry,
  ADSBVehicle: ADSBVehicle,
  HilGPS: HilGPS,
  MagnetometerReporter: MagnetometerReporter,
  ESCTelemetryItem: ESCTelemetryItem,
  Waypoint: Waypoint,
  GPSRAW: GPSRAW,
  HilSensor: HilSensor,
  TimesyncStatus: TimesyncStatus,
  Tunnel: Tunnel,
  MountControl: MountControl,
  FileEntry: FileEntry,
  LogData: LogData,
  ESCInfoItem: ESCInfoItem,
  ESCInfo: ESCInfo,
  ActuatorControl: ActuatorControl,
  Vibration: Vibration,
  HilStateQuaternion: HilStateQuaternion,
  Altitude: Altitude,
  StatusText: StatusText,
  HomePosition: HomePosition,
  RTCM: RTCM,
  ExtendedState: ExtendedState,
  DebugValue: DebugValue,
  CameraImageCaptured: CameraImageCaptured,
  WaypointList: WaypointList,
  GPSINPUT: GPSINPUT,
  ESCStatus: ESCStatus,
  EstimatorStatus: EstimatorStatus,
  HilActuatorControls: HilActuatorControls,
  OverrideRCIn: OverrideRCIn,
  PositionTarget: PositionTarget,
  OpticalFlowRad: OpticalFlowRad,
  VFR_HUD: VFR_HUD,
  Mavlink: Mavlink,
};
