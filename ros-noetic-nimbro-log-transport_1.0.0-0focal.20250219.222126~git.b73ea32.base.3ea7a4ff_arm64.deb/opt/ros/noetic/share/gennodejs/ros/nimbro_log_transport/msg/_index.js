
"use strict";

let LogBlock = require('./LogBlock.js');
let LogMsg = require('./LogMsg.js');

module.exports = {
  LogBlock: LogBlock,
  LogMsg: LogMsg,
};
