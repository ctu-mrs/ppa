// Auto-generated. Do not edit!

// (in-package nimbro_service_transport.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ServiceStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.host = null;
      this.remote = null;
      this.remote_port = null;
      this.call_id = null;
      this.service = null;
      this.status = null;
    }
    else {
      if (initObj.hasOwnProperty('host')) {
        this.host = initObj.host
      }
      else {
        this.host = '';
      }
      if (initObj.hasOwnProperty('remote')) {
        this.remote = initObj.remote
      }
      else {
        this.remote = '';
      }
      if (initObj.hasOwnProperty('remote_port')) {
        this.remote_port = initObj.remote_port
      }
      else {
        this.remote_port = 0;
      }
      if (initObj.hasOwnProperty('call_id')) {
        this.call_id = initObj.call_id
      }
      else {
        this.call_id = 0;
      }
      if (initObj.hasOwnProperty('service')) {
        this.service = initObj.service
      }
      else {
        this.service = '';
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ServiceStatus
    // Serialize message field [host]
    bufferOffset = _serializer.string(obj.host, buffer, bufferOffset);
    // Serialize message field [remote]
    bufferOffset = _serializer.string(obj.remote, buffer, bufferOffset);
    // Serialize message field [remote_port]
    bufferOffset = _serializer.uint16(obj.remote_port, buffer, bufferOffset);
    // Serialize message field [call_id]
    bufferOffset = _serializer.uint32(obj.call_id, buffer, bufferOffset);
    // Serialize message field [service]
    bufferOffset = _serializer.string(obj.service, buffer, bufferOffset);
    // Serialize message field [status]
    bufferOffset = _serializer.uint8(obj.status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ServiceStatus
    let len;
    let data = new ServiceStatus(null);
    // Deserialize message field [host]
    data.host = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [remote]
    data.remote = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [remote_port]
    data.remote_port = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [call_id]
    data.call_id = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [service]
    data.service = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [status]
    data.status = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.host);
    length += _getByteLength(object.remote);
    length += _getByteLength(object.service);
    return length + 19;
  }

  static datatype() {
    // Returns string type for a message object
    return 'nimbro_service_transport/ServiceStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2afd58b569abd78a2992e01ed942edaa';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    uint8 STATUS_FINISHED_SUCCESS = 1
    uint8 STATUS_FINISHED_ERROR = 2
    uint8 STATUS_IN_PROGRESS = 3
    uint8 STATUS_TIMEOUT = 4
    uint8 STATUS_CONNECTION_ERROR = 5
    
    string host
    string remote
    
    uint16 remote_port
    
    uint32 call_id
    string service
    uint8 status
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ServiceStatus(null);
    if (msg.host !== undefined) {
      resolved.host = msg.host;
    }
    else {
      resolved.host = ''
    }

    if (msg.remote !== undefined) {
      resolved.remote = msg.remote;
    }
    else {
      resolved.remote = ''
    }

    if (msg.remote_port !== undefined) {
      resolved.remote_port = msg.remote_port;
    }
    else {
      resolved.remote_port = 0
    }

    if (msg.call_id !== undefined) {
      resolved.call_id = msg.call_id;
    }
    else {
      resolved.call_id = 0
    }

    if (msg.service !== undefined) {
      resolved.service = msg.service;
    }
    else {
      resolved.service = ''
    }

    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    return resolved;
    }
};

// Constants for message
ServiceStatus.Constants = {
  STATUS_FINISHED_SUCCESS: 1,
  STATUS_FINISHED_ERROR: 2,
  STATUS_IN_PROGRESS: 3,
  STATUS_TIMEOUT: 4,
  STATUS_CONNECTION_ERROR: 5,
}

module.exports = ServiceStatus;
