// this file is just for documentation purposes and contains no actual code

/**
* \brief All mrs_lib functions, classes, variables and definitions are contained in this namespace.
*
*/
namespace mrs_lib {}
