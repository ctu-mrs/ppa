
"use strict";

let FileClose = require('./FileClose.js')
let MountConfigure = require('./MountConfigure.js')
let CommandVtolTransition = require('./CommandVtolTransition.js')
let CommandLong = require('./CommandLong.js')
let StreamRate = require('./StreamRate.js')
let FileRemoveDir = require('./FileRemoveDir.js')
let CommandTriggerInterval = require('./CommandTriggerInterval.js')
let FileWrite = require('./FileWrite.js')
let ParamPull = require('./ParamPull.js')
let SetMavFrame = require('./SetMavFrame.js')
let VehicleInfoGet = require('./VehicleInfoGet.js')
let MessageInterval = require('./MessageInterval.js')
let LogRequestList = require('./LogRequestList.js')
let CommandTriggerControl = require('./CommandTriggerControl.js')
let FileChecksum = require('./FileChecksum.js')
let LogRequestData = require('./LogRequestData.js')
let WaypointPush = require('./WaypointPush.js')
let FileTruncate = require('./FileTruncate.js')
let FileMakeDir = require('./FileMakeDir.js')
let CommandAck = require('./CommandAck.js')
let SetMode = require('./SetMode.js')
let CommandTOL = require('./CommandTOL.js')
let WaypointPull = require('./WaypointPull.js')
let CommandBool = require('./CommandBool.js')
let CommandHome = require('./CommandHome.js')
let ParamSet = require('./ParamSet.js')
let WaypointClear = require('./WaypointClear.js')
let FileOpen = require('./FileOpen.js')
let ParamGet = require('./ParamGet.js')
let FileRead = require('./FileRead.js')
let LogRequestEnd = require('./LogRequestEnd.js')
let WaypointSetCurrent = require('./WaypointSetCurrent.js')
let FileRemove = require('./FileRemove.js')
let FileRename = require('./FileRename.js')
let CommandInt = require('./CommandInt.js')
let FileList = require('./FileList.js')
let ParamPush = require('./ParamPush.js')

module.exports = {
  FileClose: FileClose,
  MountConfigure: MountConfigure,
  CommandVtolTransition: CommandVtolTransition,
  CommandLong: CommandLong,
  StreamRate: StreamRate,
  FileRemoveDir: FileRemoveDir,
  CommandTriggerInterval: CommandTriggerInterval,
  FileWrite: FileWrite,
  ParamPull: ParamPull,
  SetMavFrame: SetMavFrame,
  VehicleInfoGet: VehicleInfoGet,
  MessageInterval: MessageInterval,
  LogRequestList: LogRequestList,
  CommandTriggerControl: CommandTriggerControl,
  FileChecksum: FileChecksum,
  LogRequestData: LogRequestData,
  WaypointPush: WaypointPush,
  FileTruncate: FileTruncate,
  FileMakeDir: FileMakeDir,
  CommandAck: CommandAck,
  SetMode: SetMode,
  CommandTOL: CommandTOL,
  WaypointPull: WaypointPull,
  CommandBool: CommandBool,
  CommandHome: CommandHome,
  ParamSet: ParamSet,
  WaypointClear: WaypointClear,
  FileOpen: FileOpen,
  ParamGet: ParamGet,
  FileRead: FileRead,
  LogRequestEnd: LogRequestEnd,
  WaypointSetCurrent: WaypointSetCurrent,
  FileRemove: FileRemove,
  FileRename: FileRename,
  CommandInt: CommandInt,
  FileList: FileList,
  ParamPush: ParamPush,
};
