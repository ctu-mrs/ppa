
"use strict";

let StatusText = require('./StatusText.js');
let GPSINPUT = require('./GPSINPUT.js');
let CamIMUStamp = require('./CamIMUStamp.js');
let CommandCode = require('./CommandCode.js');
let VehicleInfo = require('./VehicleInfo.js');
let RCOut = require('./RCOut.js');
let Altitude = require('./Altitude.js');
let ExtendedState = require('./ExtendedState.js');
let WaypointList = require('./WaypointList.js');
let HilControls = require('./HilControls.js');
let ParamValue = require('./ParamValue.js');
let MagnetometerReporter = require('./MagnetometerReporter.js');
let RadioStatus = require('./RadioStatus.js');
let OpticalFlowRad = require('./OpticalFlowRad.js');
let EstimatorStatus = require('./EstimatorStatus.js');
let ADSBVehicle = require('./ADSBVehicle.js');
let FileEntry = require('./FileEntry.js');
let ESCTelemetry = require('./ESCTelemetry.js');
let Param = require('./Param.js');
let ESCInfoItem = require('./ESCInfoItem.js');
let MountControl = require('./MountControl.js');
let PlayTuneV2 = require('./PlayTuneV2.js');
let NavControllerOutput = require('./NavControllerOutput.js');
let VFR_HUD = require('./VFR_HUD.js');
let Tunnel = require('./Tunnel.js');
let ActuatorControl = require('./ActuatorControl.js');
let HilSensor = require('./HilSensor.js');
let TerrainReport = require('./TerrainReport.js');
let ESCTelemetryItem = require('./ESCTelemetryItem.js');
let ESCStatus = require('./ESCStatus.js');
let LogData = require('./LogData.js');
let OnboardComputerStatus = require('./OnboardComputerStatus.js');
let LogEntry = require('./LogEntry.js');
let AttitudeTarget = require('./AttitudeTarget.js');
let WheelOdomStamped = require('./WheelOdomStamped.js');
let TimesyncStatus = require('./TimesyncStatus.js');
let CompanionProcessStatus = require('./CompanionProcessStatus.js');
let PositionTarget = require('./PositionTarget.js');
let OverrideRCIn = require('./OverrideRCIn.js');
let ESCInfo = require('./ESCInfo.js');
let GPSRAW = require('./GPSRAW.js');
let GPSRTK = require('./GPSRTK.js');
let Trajectory = require('./Trajectory.js');
let ManualControl = require('./ManualControl.js');
let RTCM = require('./RTCM.js');
let HilGPS = require('./HilGPS.js');
let CameraImageCaptured = require('./CameraImageCaptured.js');
let State = require('./State.js');
let Vibration = require('./Vibration.js');
let RCIn = require('./RCIn.js');
let RTKBaseline = require('./RTKBaseline.js');
let HomePosition = require('./HomePosition.js');
let GlobalPositionTarget = require('./GlobalPositionTarget.js');
let HilActuatorControls = require('./HilActuatorControls.js');
let ESCStatusItem = require('./ESCStatusItem.js');
let LandingTarget = require('./LandingTarget.js');
let WaypointReached = require('./WaypointReached.js');
let HilStateQuaternion = require('./HilStateQuaternion.js');
let BatteryStatus = require('./BatteryStatus.js');
let Thrust = require('./Thrust.js');
let Mavlink = require('./Mavlink.js');
let Waypoint = require('./Waypoint.js');
let DebugValue = require('./DebugValue.js');

module.exports = {
  StatusText: StatusText,
  GPSINPUT: GPSINPUT,
  CamIMUStamp: CamIMUStamp,
  CommandCode: CommandCode,
  VehicleInfo: VehicleInfo,
  RCOut: RCOut,
  Altitude: Altitude,
  ExtendedState: ExtendedState,
  WaypointList: WaypointList,
  HilControls: HilControls,
  ParamValue: ParamValue,
  MagnetometerReporter: MagnetometerReporter,
  RadioStatus: RadioStatus,
  OpticalFlowRad: OpticalFlowRad,
  EstimatorStatus: EstimatorStatus,
  ADSBVehicle: ADSBVehicle,
  FileEntry: FileEntry,
  ESCTelemetry: ESCTelemetry,
  Param: Param,
  ESCInfoItem: ESCInfoItem,
  MountControl: MountControl,
  PlayTuneV2: PlayTuneV2,
  NavControllerOutput: NavControllerOutput,
  VFR_HUD: VFR_HUD,
  Tunnel: Tunnel,
  ActuatorControl: ActuatorControl,
  HilSensor: HilSensor,
  TerrainReport: TerrainReport,
  ESCTelemetryItem: ESCTelemetryItem,
  ESCStatus: ESCStatus,
  LogData: LogData,
  OnboardComputerStatus: OnboardComputerStatus,
  LogEntry: LogEntry,
  AttitudeTarget: AttitudeTarget,
  WheelOdomStamped: WheelOdomStamped,
  TimesyncStatus: TimesyncStatus,
  CompanionProcessStatus: CompanionProcessStatus,
  PositionTarget: PositionTarget,
  OverrideRCIn: OverrideRCIn,
  ESCInfo: ESCInfo,
  GPSRAW: GPSRAW,
  GPSRTK: GPSRTK,
  Trajectory: Trajectory,
  ManualControl: ManualControl,
  RTCM: RTCM,
  HilGPS: HilGPS,
  CameraImageCaptured: CameraImageCaptured,
  State: State,
  Vibration: Vibration,
  RCIn: RCIn,
  RTKBaseline: RTKBaseline,
  HomePosition: HomePosition,
  GlobalPositionTarget: GlobalPositionTarget,
  HilActuatorControls: HilActuatorControls,
  ESCStatusItem: ESCStatusItem,
  LandingTarget: LandingTarget,
  WaypointReached: WaypointReached,
  HilStateQuaternion: HilStateQuaternion,
  BatteryStatus: BatteryStatus,
  Thrust: Thrust,
  Mavlink: Mavlink,
  Waypoint: Waypoint,
  DebugValue: DebugValue,
};
