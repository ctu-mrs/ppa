
"use strict";

let CpuInfo = require('./CpuInfo.js');
let ProcessInfo = require('./ProcessInfo.js');

module.exports = {
  CpuInfo: CpuInfo,
  ProcessInfo: ProcessInfo,
};
