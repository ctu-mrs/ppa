
"use strict";

let UavDiagnostics = require('./UavDiagnostics.js');
let MpcTrackerDiagnostics = require('./MpcTrackerDiagnostics.js');
let MpcPredictionFullState = require('./MpcPredictionFullState.js');
let FutureTrajectory = require('./FutureTrajectory.js');
let FuturePoint = require('./FuturePoint.js');
let GimbalState = require('./GimbalState.js');
let RtkGps = require('./RtkGps.js');
let GpsData = require('./GpsData.js');
let RtkFixType = require('./RtkFixType.js');
let GpsInfo = require('./GpsInfo.js');
let LandoffDiagnostics = require('./LandoffDiagnostics.js');
let GazeboSpawnerDiagnostics = require('./GazeboSpawnerDiagnostics.js');
let ControllerDiagnostics = require('./ControllerDiagnostics.js');
let EstimatorCorrection = require('./EstimatorCorrection.js');
let VelocityReferenceStamped = require('./VelocityReferenceStamped.js');
let TrajectoryReference = require('./TrajectoryReference.js');
let Reference = require('./Reference.js');
let ReferenceStamped = require('./ReferenceStamped.js');
let TrackerStatus = require('./TrackerStatus.js');
let DynamicsConstraints = require('./DynamicsConstraints.js');
let ReferenceArray = require('./ReferenceArray.js');
let VelocityReference = require('./VelocityReference.js');
let EstimatorOutput = require('./EstimatorOutput.js');
let ConstraintManagerDiagnostics = require('./ConstraintManagerDiagnostics.js');
let PathReference = require('./PathReference.js');
let TrackerCommand = require('./TrackerCommand.js');
let GainManagerDiagnostics = require('./GainManagerDiagnostics.js');
let EstimatorDiagnostics = require('./EstimatorDiagnostics.js');
let ControlError = require('./ControlError.js');
let EulerAngles = require('./EulerAngles.js');
let EstimationDiagnostics = require('./EstimationDiagnostics.js');
let UavManagerDiagnostics = require('./UavManagerDiagnostics.js');
let ControllerStatus = require('./ControllerStatus.js');
let ControlManagerDiagnostics = require('./ControlManagerDiagnostics.js');
let EstimatorInput = require('./EstimatorInput.js');
let UavState = require('./UavState.js');
let NodeCpuLoad = require('./NodeCpuLoad.js');
let UavStatusShort = require('./UavStatusShort.js');
let UavStatus = require('./UavStatus.js');
let CustomTopic = require('./CustomTopic.js');
let Se3Gains = require('./Se3Gains.js');
let PathWithVelocity = require('./PathWithVelocity.js');
let Path = require('./Path.js');
let ReferenceWithVelocity = require('./ReferenceWithVelocity.js');
let ProfilerUpdate = require('./ProfilerUpdate.js');
let Histogram = require('./Histogram.js');
let ObstacleSectors = require('./ObstacleSectors.js');
let SpeedTrackerCommand = require('./SpeedTrackerCommand.js');
let TrackArrayStamped = require('./TrackArrayStamped.js');
let Float64 = require('./Float64.js');
let Sphere = require('./Sphere.js');
let Float64MultiArrayStamped = require('./Float64MultiArrayStamped.js');
let Float64ArrayStamped = require('./Float64ArrayStamped.js');
let RangeWithCovarianceIdentified = require('./RangeWithCovarianceIdentified.js');
let PoseWithCovarianceIdentified = require('./PoseWithCovarianceIdentified.js');
let ImageLabeledArray = require('./ImageLabeledArray.js');
let Float64Stamped = require('./Float64Stamped.js');
let RangeWithCovarianceArrayStamped = require('./RangeWithCovarianceArrayStamped.js');
let StringStamped = require('./StringStamped.js');
let PoseWithCovarianceArrayStamped = require('./PoseWithCovarianceArrayStamped.js');
let Track = require('./Track.js');
let ImageLabeled = require('./ImageLabeled.js');
let TrackStamped = require('./TrackStamped.js');
let BoolStamped = require('./BoolStamped.js');
let UInt16Stamped = require('./UInt16Stamped.js');
let HwApiCapabilities = require('./HwApiCapabilities.js');
let HwApiRcChannels = require('./HwApiRcChannels.js');
let HwApiAltitude = require('./HwApiAltitude.js');
let HwApiActuatorCmd = require('./HwApiActuatorCmd.js');
let HwApiAttitudeRateCmd = require('./HwApiAttitudeRateCmd.js');
let HwApiPositionCmd = require('./HwApiPositionCmd.js');
let HwApiStatus = require('./HwApiStatus.js');
let HwApiVelocityHdgCmd = require('./HwApiVelocityHdgCmd.js');
let HwApiAccelerationHdgRateCmd = require('./HwApiAccelerationHdgRateCmd.js');
let HwApiControlGroupCmd = require('./HwApiControlGroupCmd.js');
let HwApiAttitudeCmd = require('./HwApiAttitudeCmd.js');
let HwApiAccelerationHdgCmd = require('./HwApiAccelerationHdgCmd.js');
let HwApiVelocityHdgRateCmd = require('./HwApiVelocityHdgRateCmd.js');

module.exports = {
  UavDiagnostics: UavDiagnostics,
  MpcTrackerDiagnostics: MpcTrackerDiagnostics,
  MpcPredictionFullState: MpcPredictionFullState,
  FutureTrajectory: FutureTrajectory,
  FuturePoint: FuturePoint,
  GimbalState: GimbalState,
  RtkGps: RtkGps,
  GpsData: GpsData,
  RtkFixType: RtkFixType,
  GpsInfo: GpsInfo,
  LandoffDiagnostics: LandoffDiagnostics,
  GazeboSpawnerDiagnostics: GazeboSpawnerDiagnostics,
  ControllerDiagnostics: ControllerDiagnostics,
  EstimatorCorrection: EstimatorCorrection,
  VelocityReferenceStamped: VelocityReferenceStamped,
  TrajectoryReference: TrajectoryReference,
  Reference: Reference,
  ReferenceStamped: ReferenceStamped,
  TrackerStatus: TrackerStatus,
  DynamicsConstraints: DynamicsConstraints,
  ReferenceArray: ReferenceArray,
  VelocityReference: VelocityReference,
  EstimatorOutput: EstimatorOutput,
  ConstraintManagerDiagnostics: ConstraintManagerDiagnostics,
  PathReference: PathReference,
  TrackerCommand: TrackerCommand,
  GainManagerDiagnostics: GainManagerDiagnostics,
  EstimatorDiagnostics: EstimatorDiagnostics,
  ControlError: ControlError,
  EulerAngles: EulerAngles,
  EstimationDiagnostics: EstimationDiagnostics,
  UavManagerDiagnostics: UavManagerDiagnostics,
  ControllerStatus: ControllerStatus,
  ControlManagerDiagnostics: ControlManagerDiagnostics,
  EstimatorInput: EstimatorInput,
  UavState: UavState,
  NodeCpuLoad: NodeCpuLoad,
  UavStatusShort: UavStatusShort,
  UavStatus: UavStatus,
  CustomTopic: CustomTopic,
  Se3Gains: Se3Gains,
  PathWithVelocity: PathWithVelocity,
  Path: Path,
  ReferenceWithVelocity: ReferenceWithVelocity,
  ProfilerUpdate: ProfilerUpdate,
  Histogram: Histogram,
  ObstacleSectors: ObstacleSectors,
  SpeedTrackerCommand: SpeedTrackerCommand,
  TrackArrayStamped: TrackArrayStamped,
  Float64: Float64,
  Sphere: Sphere,
  Float64MultiArrayStamped: Float64MultiArrayStamped,
  Float64ArrayStamped: Float64ArrayStamped,
  RangeWithCovarianceIdentified: RangeWithCovarianceIdentified,
  PoseWithCovarianceIdentified: PoseWithCovarianceIdentified,
  ImageLabeledArray: ImageLabeledArray,
  Float64Stamped: Float64Stamped,
  RangeWithCovarianceArrayStamped: RangeWithCovarianceArrayStamped,
  StringStamped: StringStamped,
  PoseWithCovarianceArrayStamped: PoseWithCovarianceArrayStamped,
  Track: Track,
  ImageLabeled: ImageLabeled,
  TrackStamped: TrackStamped,
  BoolStamped: BoolStamped,
  UInt16Stamped: UInt16Stamped,
  HwApiCapabilities: HwApiCapabilities,
  HwApiRcChannels: HwApiRcChannels,
  HwApiAltitude: HwApiAltitude,
  HwApiActuatorCmd: HwApiActuatorCmd,
  HwApiAttitudeRateCmd: HwApiAttitudeRateCmd,
  HwApiPositionCmd: HwApiPositionCmd,
  HwApiStatus: HwApiStatus,
  HwApiVelocityHdgCmd: HwApiVelocityHdgCmd,
  HwApiAccelerationHdgRateCmd: HwApiAccelerationHdgRateCmd,
  HwApiControlGroupCmd: HwApiControlGroupCmd,
  HwApiAttitudeCmd: HwApiAttitudeCmd,
  HwApiAccelerationHdgCmd: HwApiAccelerationHdgCmd,
  HwApiVelocityHdgRateCmd: HwApiVelocityHdgRateCmd,
};
