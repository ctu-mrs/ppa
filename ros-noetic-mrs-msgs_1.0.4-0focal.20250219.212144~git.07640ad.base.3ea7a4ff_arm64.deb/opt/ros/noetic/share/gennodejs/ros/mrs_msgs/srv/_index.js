
"use strict";

let PathSrv = require('./PathSrv.js')
let GetPathSrv = require('./GetPathSrv.js')

module.exports = {
  PathSrv: PathSrv,
  GetPathSrv: GetPathSrv,
};
