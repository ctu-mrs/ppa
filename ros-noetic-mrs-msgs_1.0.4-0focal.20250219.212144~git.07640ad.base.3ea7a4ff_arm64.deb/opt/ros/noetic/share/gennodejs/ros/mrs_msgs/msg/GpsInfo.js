// Auto-generated. Do not edit!

// (in-package mrs_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class GpsInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.fix_type = null;
      this.lat = null;
      this.lon = null;
      this.alt = null;
      this.eph = null;
      this.epv = null;
      this.vel = null;
      this.cog = null;
      this.satellites_visible = null;
      this.alt_ellipsoid = null;
      this.h_acc = null;
      this.v_acc = null;
      this.vel_acc = null;
      this.hdg_acc = null;
      this.yaw = null;
      this.dgps_num_sats = null;
      this.dgps_age = null;
      this.baseline_dist = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('fix_type')) {
        this.fix_type = initObj.fix_type
      }
      else {
        this.fix_type = 0;
      }
      if (initObj.hasOwnProperty('lat')) {
        this.lat = initObj.lat
      }
      else {
        this.lat = 0.0;
      }
      if (initObj.hasOwnProperty('lon')) {
        this.lon = initObj.lon
      }
      else {
        this.lon = 0.0;
      }
      if (initObj.hasOwnProperty('alt')) {
        this.alt = initObj.alt
      }
      else {
        this.alt = 0.0;
      }
      if (initObj.hasOwnProperty('eph')) {
        this.eph = initObj.eph
      }
      else {
        this.eph = 0;
      }
      if (initObj.hasOwnProperty('epv')) {
        this.epv = initObj.epv
      }
      else {
        this.epv = 0;
      }
      if (initObj.hasOwnProperty('vel')) {
        this.vel = initObj.vel
      }
      else {
        this.vel = 0.0;
      }
      if (initObj.hasOwnProperty('cog')) {
        this.cog = initObj.cog
      }
      else {
        this.cog = 0.0;
      }
      if (initObj.hasOwnProperty('satellites_visible')) {
        this.satellites_visible = initObj.satellites_visible
      }
      else {
        this.satellites_visible = 0;
      }
      if (initObj.hasOwnProperty('alt_ellipsoid')) {
        this.alt_ellipsoid = initObj.alt_ellipsoid
      }
      else {
        this.alt_ellipsoid = 0.0;
      }
      if (initObj.hasOwnProperty('h_acc')) {
        this.h_acc = initObj.h_acc
      }
      else {
        this.h_acc = 0.0;
      }
      if (initObj.hasOwnProperty('v_acc')) {
        this.v_acc = initObj.v_acc
      }
      else {
        this.v_acc = 0.0;
      }
      if (initObj.hasOwnProperty('vel_acc')) {
        this.vel_acc = initObj.vel_acc
      }
      else {
        this.vel_acc = 0.0;
      }
      if (initObj.hasOwnProperty('hdg_acc')) {
        this.hdg_acc = initObj.hdg_acc
      }
      else {
        this.hdg_acc = 0.0;
      }
      if (initObj.hasOwnProperty('yaw')) {
        this.yaw = initObj.yaw
      }
      else {
        this.yaw = 0.0;
      }
      if (initObj.hasOwnProperty('dgps_num_sats')) {
        this.dgps_num_sats = initObj.dgps_num_sats
      }
      else {
        this.dgps_num_sats = 0;
      }
      if (initObj.hasOwnProperty('dgps_age')) {
        this.dgps_age = initObj.dgps_age
      }
      else {
        this.dgps_age = 0.0;
      }
      if (initObj.hasOwnProperty('baseline_dist')) {
        this.baseline_dist = initObj.baseline_dist
      }
      else {
        this.baseline_dist = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GpsInfo
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [fix_type]
    bufferOffset = _serializer.uint8(obj.fix_type, buffer, bufferOffset);
    // Serialize message field [lat]
    bufferOffset = _serializer.float64(obj.lat, buffer, bufferOffset);
    // Serialize message field [lon]
    bufferOffset = _serializer.float64(obj.lon, buffer, bufferOffset);
    // Serialize message field [alt]
    bufferOffset = _serializer.float32(obj.alt, buffer, bufferOffset);
    // Serialize message field [eph]
    bufferOffset = _serializer.uint16(obj.eph, buffer, bufferOffset);
    // Serialize message field [epv]
    bufferOffset = _serializer.uint16(obj.epv, buffer, bufferOffset);
    // Serialize message field [vel]
    bufferOffset = _serializer.float32(obj.vel, buffer, bufferOffset);
    // Serialize message field [cog]
    bufferOffset = _serializer.float32(obj.cog, buffer, bufferOffset);
    // Serialize message field [satellites_visible]
    bufferOffset = _serializer.uint8(obj.satellites_visible, buffer, bufferOffset);
    // Serialize message field [alt_ellipsoid]
    bufferOffset = _serializer.float32(obj.alt_ellipsoid, buffer, bufferOffset);
    // Serialize message field [h_acc]
    bufferOffset = _serializer.float32(obj.h_acc, buffer, bufferOffset);
    // Serialize message field [v_acc]
    bufferOffset = _serializer.float32(obj.v_acc, buffer, bufferOffset);
    // Serialize message field [vel_acc]
    bufferOffset = _serializer.float32(obj.vel_acc, buffer, bufferOffset);
    // Serialize message field [hdg_acc]
    bufferOffset = _serializer.float32(obj.hdg_acc, buffer, bufferOffset);
    // Serialize message field [yaw]
    bufferOffset = _serializer.float32(obj.yaw, buffer, bufferOffset);
    // Serialize message field [dgps_num_sats]
    bufferOffset = _serializer.uint8(obj.dgps_num_sats, buffer, bufferOffset);
    // Serialize message field [dgps_age]
    bufferOffset = _serializer.float32(obj.dgps_age, buffer, bufferOffset);
    // Serialize message field [baseline_dist]
    bufferOffset = _serializer.float32(obj.baseline_dist, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GpsInfo
    let len;
    let data = new GpsInfo(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [fix_type]
    data.fix_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [lat]
    data.lat = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [lon]
    data.lon = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [alt]
    data.alt = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [eph]
    data.eph = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [epv]
    data.epv = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [vel]
    data.vel = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [cog]
    data.cog = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [satellites_visible]
    data.satellites_visible = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [alt_ellipsoid]
    data.alt_ellipsoid = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [h_acc]
    data.h_acc = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [v_acc]
    data.v_acc = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [vel_acc]
    data.vel_acc = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [hdg_acc]
    data.hdg_acc = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [yaw]
    data.yaw = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [dgps_num_sats]
    data.dgps_num_sats = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [dgps_age]
    data.dgps_age = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [baseline_dist]
    data.baseline_dist = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 75;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_msgs/GpsInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f63b1f2ded0353fd2f8cdc25e5ad89c9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time stamp
    ## GPS_FIX_TYPE enum
    
    uint8 GPS_FIX_TYPE_NO_GPS     = 0    # No GPS connected
    uint8 GPS_FIX_TYPE_NO_FIX     = 1    # No position information, GPS is connected
    uint8 GPS_FIX_TYPE_2D_FIX     = 2    # 2D position
    uint8 GPS_FIX_TYPE_3D_FIX     = 3    # 3D position
    uint8 GPS_FIX_TYPE_DGPS       = 4    # DGPS/SBAS aided 3D position
    uint8 GPS_FIX_TYPE_RTK_FLOATR = 5    # TK float, 3D position
    uint8 GPS_FIX_TYPE_RTK_FIXEDR = 6    # TK Fixed, 3D position
    uint8 GPS_FIX_TYPE_STATIC     = 7    # Static fixed, typically used for base stations
    uint8 GPS_FIX_TYPE_PPP        = 8    # PPP, 3D position
    uint8 fix_type      # [GPS_FIX_TYPE] GPS fix type
    
    float64 lat              # [deg] Latitude (WGS84, EGM96 ellipsoid)
    float64 lon              # [deg] Longitude (WGS84, EGM96 ellipsoid)
    float32 alt              # [m] Altitude (MSL). Positive for up. Note that virtually all GPS modules provide the MSL altitude in addition to the WGS84 altitude.
    uint16 eph               # GPS HDOP horizontal dilution of position (unitless). If unknown, set to: UINT16_MAX
    uint16 epv               # GPS VDOP vertical dilution of position (unitless). If unknown, set to: UINT16_MAX
    float32 vel              # [m/s] GPS ground speed. If unknown, set to: UINT16_MAX
    float32 cog              # [deg] Course over ground (NOT heading, but direction of movement), 0.0..359.99 degrees. If unknown, set to: UINT16_MAX
    uint8 satellites_visible # Number of satellites visible. If unknown, set to 255
    
    float32 alt_ellipsoid    # [m] Altitude (above WGS84, EGM96 ellipsoid). Positive for up.
    float32 h_acc            # [m] Position uncertainty. Positive for up.
    float32 v_acc            # [m] Altitude uncertainty. Positive for up.
    float32 vel_acc          # [m/s] Speed uncertainty. Positive for up.
    float32 hdg_acc          # [deg] Heading / track uncertainty
    float32 yaw              # [deg] Yaw in earth frame from north.
    
    uint8 dgps_num_sats      # Number of DGPS satellites
    float32 dgps_age          # [s] Age of DGPS info
    float32 baseline_dist     # [m] distance to the basestation
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GpsInfo(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.fix_type !== undefined) {
      resolved.fix_type = msg.fix_type;
    }
    else {
      resolved.fix_type = 0
    }

    if (msg.lat !== undefined) {
      resolved.lat = msg.lat;
    }
    else {
      resolved.lat = 0.0
    }

    if (msg.lon !== undefined) {
      resolved.lon = msg.lon;
    }
    else {
      resolved.lon = 0.0
    }

    if (msg.alt !== undefined) {
      resolved.alt = msg.alt;
    }
    else {
      resolved.alt = 0.0
    }

    if (msg.eph !== undefined) {
      resolved.eph = msg.eph;
    }
    else {
      resolved.eph = 0
    }

    if (msg.epv !== undefined) {
      resolved.epv = msg.epv;
    }
    else {
      resolved.epv = 0
    }

    if (msg.vel !== undefined) {
      resolved.vel = msg.vel;
    }
    else {
      resolved.vel = 0.0
    }

    if (msg.cog !== undefined) {
      resolved.cog = msg.cog;
    }
    else {
      resolved.cog = 0.0
    }

    if (msg.satellites_visible !== undefined) {
      resolved.satellites_visible = msg.satellites_visible;
    }
    else {
      resolved.satellites_visible = 0
    }

    if (msg.alt_ellipsoid !== undefined) {
      resolved.alt_ellipsoid = msg.alt_ellipsoid;
    }
    else {
      resolved.alt_ellipsoid = 0.0
    }

    if (msg.h_acc !== undefined) {
      resolved.h_acc = msg.h_acc;
    }
    else {
      resolved.h_acc = 0.0
    }

    if (msg.v_acc !== undefined) {
      resolved.v_acc = msg.v_acc;
    }
    else {
      resolved.v_acc = 0.0
    }

    if (msg.vel_acc !== undefined) {
      resolved.vel_acc = msg.vel_acc;
    }
    else {
      resolved.vel_acc = 0.0
    }

    if (msg.hdg_acc !== undefined) {
      resolved.hdg_acc = msg.hdg_acc;
    }
    else {
      resolved.hdg_acc = 0.0
    }

    if (msg.yaw !== undefined) {
      resolved.yaw = msg.yaw;
    }
    else {
      resolved.yaw = 0.0
    }

    if (msg.dgps_num_sats !== undefined) {
      resolved.dgps_num_sats = msg.dgps_num_sats;
    }
    else {
      resolved.dgps_num_sats = 0
    }

    if (msg.dgps_age !== undefined) {
      resolved.dgps_age = msg.dgps_age;
    }
    else {
      resolved.dgps_age = 0.0
    }

    if (msg.baseline_dist !== undefined) {
      resolved.baseline_dist = msg.baseline_dist;
    }
    else {
      resolved.baseline_dist = 0.0
    }

    return resolved;
    }
};

// Constants for message
GpsInfo.Constants = {
  GPS_FIX_TYPE_NO_GPS: 0,
  GPS_FIX_TYPE_NO_FIX: 1,
  GPS_FIX_TYPE_2D_FIX: 2,
  GPS_FIX_TYPE_3D_FIX: 3,
  GPS_FIX_TYPE_DGPS: 4,
  GPS_FIX_TYPE_RTK_FLOATR: 5,
  GPS_FIX_TYPE_RTK_FIXEDR: 6,
  GPS_FIX_TYPE_STATIC: 7,
  GPS_FIX_TYPE_PPP: 8,
}

module.exports = GpsInfo;
