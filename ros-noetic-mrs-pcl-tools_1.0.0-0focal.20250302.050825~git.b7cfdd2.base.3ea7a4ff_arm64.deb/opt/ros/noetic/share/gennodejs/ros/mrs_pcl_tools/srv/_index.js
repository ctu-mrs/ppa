
"use strict";

let SrvRegisterPointCloudOffline = require('./SrvRegisterPointCloudOffline.js')
let SrvRegisterPointCloudByName = require('./SrvRegisterPointCloudByName.js')

module.exports = {
  SrvRegisterPointCloudOffline: SrvRegisterPointCloudOffline,
  SrvRegisterPointCloudByName: SrvRegisterPointCloudByName,
};
