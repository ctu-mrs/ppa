// Auto-generated. Do not edit!

// (in-package uvdar_core.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class RecMsg {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.pl_carrying = null;
      this.uav_id = null;
      this.heading = null;
      this.msg_type = null;
      this.payload = null;
    }
    else {
      if (initObj.hasOwnProperty('pl_carrying')) {
        this.pl_carrying = initObj.pl_carrying
      }
      else {
        this.pl_carrying = false;
      }
      if (initObj.hasOwnProperty('uav_id')) {
        this.uav_id = initObj.uav_id
      }
      else {
        this.uav_id = 0;
      }
      if (initObj.hasOwnProperty('heading')) {
        this.heading = initObj.heading
      }
      else {
        this.heading = 0.0;
      }
      if (initObj.hasOwnProperty('msg_type')) {
        this.msg_type = initObj.msg_type
      }
      else {
        this.msg_type = 0;
      }
      if (initObj.hasOwnProperty('payload')) {
        this.payload = initObj.payload
      }
      else {
        this.payload = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RecMsg
    // Serialize message field [pl_carrying]
    bufferOffset = _serializer.bool(obj.pl_carrying, buffer, bufferOffset);
    // Serialize message field [uav_id]
    bufferOffset = _serializer.int32(obj.uav_id, buffer, bufferOffset);
    // Serialize message field [heading]
    bufferOffset = _serializer.float32(obj.heading, buffer, bufferOffset);
    // Serialize message field [msg_type]
    bufferOffset = _serializer.int32(obj.msg_type, buffer, bufferOffset);
    // Serialize message field [payload]
    bufferOffset = _arraySerializer.float32(obj.payload, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RecMsg
    let len;
    let data = new RecMsg(null);
    // Deserialize message field [pl_carrying]
    data.pl_carrying = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [uav_id]
    data.uav_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [heading]
    data.heading = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [msg_type]
    data.msg_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [payload]
    data.payload = _arrayDeserializer.float32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 4 * object.payload.length;
    return length + 17;
  }

  static datatype() {
    // Returns string type for a message object
    return 'uvdar_core/RecMsg';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '258207300cdd4b25d2db94483c10271b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #Received msg
    bool pl_carrying
    int32 uav_id
    float32 heading
    int32 msg_type
    float32[] payload
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RecMsg(null);
    if (msg.pl_carrying !== undefined) {
      resolved.pl_carrying = msg.pl_carrying;
    }
    else {
      resolved.pl_carrying = false
    }

    if (msg.uav_id !== undefined) {
      resolved.uav_id = msg.uav_id;
    }
    else {
      resolved.uav_id = 0
    }

    if (msg.heading !== undefined) {
      resolved.heading = msg.heading;
    }
    else {
      resolved.heading = 0.0
    }

    if (msg.msg_type !== undefined) {
      resolved.msg_type = msg.msg_type;
    }
    else {
      resolved.msg_type = 0
    }

    if (msg.payload !== undefined) {
      resolved.payload = msg.payload;
    }
    else {
      resolved.payload = []
    }

    return resolved;
    }
};

module.exports = RecMsg;
