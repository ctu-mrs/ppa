// Auto-generated. Do not edit!

// (in-package uvdar_core.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Point2DWithFloat = require('./Point2DWithFloat.js');

//-----------------------------------------------------------

class AMISeqPoint {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.insert_time = null;
      this.point = null;
    }
    else {
      if (initObj.hasOwnProperty('insert_time')) {
        this.insert_time = initObj.insert_time
      }
      else {
        this.insert_time = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('point')) {
        this.point = initObj.point
      }
      else {
        this.point = new Point2DWithFloat();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AMISeqPoint
    // Serialize message field [insert_time]
    bufferOffset = _serializer.time(obj.insert_time, buffer, bufferOffset);
    // Serialize message field [point]
    bufferOffset = Point2DWithFloat.serialize(obj.point, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AMISeqPoint
    let len;
    let data = new AMISeqPoint(null);
    // Deserialize message field [insert_time]
    data.insert_time = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [point]
    data.point = Point2DWithFloat.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 32;
  }

  static datatype() {
    // Returns string type for a message object
    return 'uvdar_core/AMISeqPoint';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e07590dc19e142a3fae21390f4e06a91';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time insert_time
    uvdar_core/Point2DWithFloat point
    ================================================================================
    MSG: uvdar_core/Point2DWithFloat
    float64 x
    float64 y
    float64 value
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AMISeqPoint(null);
    if (msg.insert_time !== undefined) {
      resolved.insert_time = msg.insert_time;
    }
    else {
      resolved.insert_time = {secs: 0, nsecs: 0}
    }

    if (msg.point !== undefined) {
      resolved.point = Point2DWithFloat.Resolve(msg.point)
    }
    else {
      resolved.point = new Point2DWithFloat()
    }

    return resolved;
    }
};

module.exports = AMISeqPoint;
