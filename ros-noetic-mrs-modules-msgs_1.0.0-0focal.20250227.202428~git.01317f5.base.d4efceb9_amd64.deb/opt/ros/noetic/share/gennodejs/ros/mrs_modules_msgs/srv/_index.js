
"use strict";

let SetTrigger = require('./SetTrigger.js')
let SetServo = require('./SetServo.js')

module.exports = {
  SetTrigger: SetTrigger,
  SetServo: SetServo,
};
